#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import mysql.connector

config = {
    "user": "case_study_user",
    "password": "popcorn",
    "host": "127.0.0.1",
    "database": "case_study",
    "raise_on_warnings": True
}

db = mysql.connector.connect(*config)
cursor = db.cursor()

cursor.execute("SELECT t2.product_id, t2.product_name, SUM( t1.quantity (t1.unit_price - t1.discount))"
               "AS product_sales "
               "FROM order_details t1 "
               "RIGHT JOIN product t2 "
               "ON t1.product_id = t2.product_id "
               "GROUP BY t2.product_id;")

product_sales = cursor.fetchall()
for sale in product_sales:
    print("Product ID: {}\nProduct Name: {}\nTotal Product Sales: {}\n".format(sale[0], sale[1], sale[2]))

cursor.execute("SELECT SUM(quantity * (unit_price - discount)) AS total_sales FROM order_details;")
total_sales = cursor.fetchall()
for sale in total_sales:
    print("Total Overall Sales: {}".format(sale[0]))


cursor.close()
db.close()

